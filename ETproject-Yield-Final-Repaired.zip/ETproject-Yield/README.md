# 💰 HYIP Investment Project (ETyield)

This is a mobile-optimized High Yield Investment Program (HYIP) platform with frontend and backend integration, built entirely using Acode on Android and deployed via Vercel.

## 📱 Features

### User Panel:
- ✅ Register and login system
- 💵 Deposit system with minimum deposit of 500 birr (CBE)
- 📤 Withdrawal system with 5% gas fee (min 150 birr, CBE only)
- 💳 Buy VIP Plans (V1–V6) with different prices and daily incomes
- 👥 Referral system (3 levels):
  - Level 1: 11%
  - Level 2: 3%
  - Level 3: 1%
- ⚙️ Settings page to store full name and bank info
- 📈 Dashboard with real-time balance
- 🔁 Auto referral tracking
- 💬 Telegram support and channel links

### Admin Panel:
- 🔐 Admin login authentication
- 📥 View & manage user deposits
- 📤 View & manage withdrawals
- 🧑‍💼 Manage users
- 📊 Referral analytics
- ⚙️ System settings

---

## 📁 Project Structure