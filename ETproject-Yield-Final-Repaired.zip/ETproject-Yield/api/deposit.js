import fs from 'fs';
import path from 'path';

const depositsFile = path.join(process.cwd(), 'data', 'deposits.json'); // adjust path if needed

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { name, account, amount, transactionId } = req.body;

  // Validate inputs
  if (
    !name ||
    !account ||
    !amount ||
    !transactionId ||
    typeof name !== 'string' ||
    typeof account !== 'string' ||
    typeof transactionId !== 'string' ||
    isNaN(amount) ||
    amount < 500
  ) {
    return res.status(400).json({ error: 'Invalid input or minimum deposit is 500 birr' });
  }

  try {
    // Read existing deposits
    let depositsData = [];
    if (fs.existsSync(depositsFile)) {
      const fileContent = fs.readFileSync(depositsFile, 'utf8');
      depositsData = JSON.parse(fileContent);
    }

    // Create new deposit object
    const newDeposit = {
      id: transactionId,
      name,
      account,
      amount: Number(amount),
      transactionId,
      date: new Date().toISOString(),
      status: 'pending',
    };

    // Add new deposit
    depositsData.push(newDeposit);

    // Save back to file
    fs.writeFileSync(depositsFile, JSON.stringify(depositsData, null, 2));

    return res.status(201).json({ message: 'Deposit request submitted successfully' });
  } catch (error) {
    console.error('Deposit error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}