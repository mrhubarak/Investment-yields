import fs from 'fs';
import path from 'path';

export default async function handler(req, res) {
  const filePath = path.resolve('./data', 'withdrawals.json');

  if (req.method === 'POST') {
    try {
      const { name, accountNumber, amount } = req.body;

      // Validations
      if (!name || !accountNumber || !amount || amount < 150) {
        return res.status(400).json({ message: 'Invalid or minimum withdrawal is 150 birr.' });
      }

      const gasFee = Math.floor(amount * 0.05); // 5% fee
      const netAmount = amount - gasFee;

      const newRequest = {
        id: Date.now(),
        name,
        accountNumber,
        amount,
        gasFee,
        netAmount,
        status: 'pending',
        date: new Date().toISOString()
      };

      let withdrawals = [];
      if (fs.existsSync(filePath)) {
        withdrawals = JSON.parse(fs.readFileSync(filePath));
      }

      withdrawals.push(newRequest);
      fs.writeFileSync(filePath, JSON.stringify(withdrawals, null, 2));

      return res.status(200).json({ message: 'Withdrawal submitted', netAmount, gasFee });
    } catch (error) {
      return res.status(500).json({ message: 'Error saving withdrawal.' });
    }
  } else {
    return res.status(405).json({ message: 'Only POST allowed' });
  }
}