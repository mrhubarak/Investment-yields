import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  const dataPath = path.resolve('./data/withdrawals.json');

  let withdrawals = [];
  if (fs.existsSync(dataPath)) {
    withdrawals = JSON.parse(fs.readFileSync(dataPath));
  }

  res.status(200).json(withdrawals);
}