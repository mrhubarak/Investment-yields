import fs from 'fs';
import path from 'path';

export default function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ message: 'Method not allowed' });

  const { index, status } = req.body;

  if (typeof index !== 'number' || !['approved', 'rejected'].includes(status)) {
    return res.status(400).json({ message: 'Invalid data' });
  }

  const dataPath = path.resolve('./data/withdrawals.json');

  let withdrawals = [];
  if (fs.existsSync(dataPath)) {
    withdrawals = JSON.parse(fs.readFileSync(dataPath));
  } else {
    return res.status(404).json({ message: 'Withdrawals data not found' });
  }

  if (index < 0 || index >= withdrawals.length) {
    return res.status(400).json({ message: 'Invalid index' });
  }

  withdrawals[index].status = status;

  fs.writeFileSync(dataPath, JSON.stringify(withdrawals, null, 2));

  res.status(200).json({ message: 'Status updated' });
}