// balance.js

// Function to get balance from localStorage, default to 0 if none
function getBalance() {
  let bal = localStorage.getItem('balance');
  if (!bal) {
    localStorage.setItem('balance', '0');
    return 0;
  }
  return parseFloat(bal);
}

// Function to set balance in localStorage and update UI
function setBalance(newBalance) {
  localStorage.setItem('balance', newBalance.toFixed(2));
  updateBalanceUI();
}

// Function to update the balance display in the DOM
function updateBalanceUI() {
  const balanceElement = document.getElementById('balance');
  if (balanceElement) {
    const bal = getBalance();
    balanceElement.textContent = `Birr ${bal.toFixed(2)}`;
  }
}

// Initialize display on page load
document.addEventListener('DOMContentLoaded', () => {
  updateBalanceUI();
});

// Example: You can call setBalance() to update balance after deposits or withdrawals
// setBalance(1000);